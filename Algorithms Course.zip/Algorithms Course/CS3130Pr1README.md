Problem1 shows that n = 41 for approximately 60 sec.
Problem2 shows that python does not have a problem with overflow due to arbitrary precision-it is only limited by memory available.
Problem3 shows that it takes 4.8 msecs to calculate F10000.
